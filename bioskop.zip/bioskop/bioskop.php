<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="keywords" content="bioskop, bioskop horor, tiket murah">
  <meta name="description" content="Website kopi kita aja">

  <link rel="stylesheet" href="styles/bootstrap.min.css">
  <link rel="shortcut icon" href="assets/logo.png" type="image/x-icon">
  <link rel="stylesheet" href="styles/styles.css">

  <!-- Font Horror -->
  <link href="https://fonts.googleapis.com/css2?family=Creepster&display=swap" rel="stylesheet">
  <style>
    /* FONT HORROR UNTUK SEMUA TEKS */
    * {
      font-family: 'Creepster', cursive !important;
      color: #e0e0e0 !important; /* abu terang agar terlihat di latar gelap */
    }

    body {
      background-color: #0d0d0d;
      background-image: url('assets/horror-bg.jpg'); /* kalau kamu punya gambar latar belakang horor */
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
    }

    .navbar, footer {
      background-color: rgba(10, 10, 10, 0.9) !important;
    }

    .navbar .nav-link, .navbar-brand {
      color: #ff4444 ;
    }

    .navbar .nav-link:hover {
      color: #ff0000 !important;
    }

    h2, h3, h5, h1, h4 {
      color: #ff4444 !important;
      text-shadow: 2px 2px 4px #000;
    }

    .carousel-caption {
      background-color: rgba(0, 0, 0, 0.7);
      padding: 1rem;
    }

    .card {
      background-color: rgba(20, 20, 20, 0.9) !important;
      border: 1px solid #660000 !important;
    }

    .card-title, .card-text {
      color: #f4f4f4 !important;
    }

    .btn {
      background-color: #990000 !important;
      border-color: #660000 !important;
      color: #ffffff !important;
    }

    .btn:hover {
      background-color: #ff0000 !important;
      border-color: #880000 !important;
    }

    .portrait-img {
      height: 500px;
      width: auto;
      object-fit: cover;
      display: block;
      margin: 0 auto;
      border: 2px solid #660000;
    }

    .bg-light {
      background-color: rgba(30, 30, 30, 0.9) !important;
    }

    #review .card {
      background-color: rgba(25, 25, 25, 0.9) !important;
    }

    #contact, #profile {
      background-color: rgba(15, 15, 15, 0.95);
      padding: 2rem 0;
    }

    a, p {
      color: #e0e0e0 !important;
    }

    a:hover {
      color: #ff4444 !important;
    }

    .placeholder {
   display: block;
   text-align: center;
  margin-top: 10px;
   font-size: 1.2rem;
  color: black;
  opacity: 0.5; /* ini membuat teks transparan */
}

.zse {
  text-align: center;
}

  </style>

  <title>bioskob horror</title>
</head>
<body>
  <!-- Navbar (Bootstrap) -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <a class="navbar-brand" href="#">
      <img src="assets/logo.png" alt="logo" width="30" height="30" class="d-inline-block align-top">
      HORSKOB
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="ml-auto navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="#banner">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#Menu">Menu</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#profile">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contact">Kontak</a>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Banner -->
  <div id="banner" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#banner" data-slide-to="0" class="active"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="assets/home.jpg" class="d-block w-100" alt="Kopi Kita Banner">
        <div class="carousel-caption d-none d-md-block">
          <h5>HORSKOB</h5>
          <p>Bioskop horor terbaik dengan film paling seram diseluruh dunia</p>
        </div>
      </div>
    </div>
  </div>
<br><br><br>
  <p><center><h2>FILM TERATAS</h2></center></p>

  <div id="q-menu" class="p-100" style="margin-top: 72px;">
    <div class="row">
      <div class="col-lg-4">
        <a href="#menu" class="card" style="width: 100%;">
          <img src="assets/OIP (3).jpg" class="card-img-top" alt="Menu">
          <a href="#Menu" class="placeholder">horskob</a>
        </a>
      </div>
      <div class="col-lg-4">
        <a href="#profile" class="card" style="width: 100%;">
          <img src="assets/OIP (1).jpg" class="card-img-top" alt="Menu">
          <a href="#profile" class="placeholder">horskob</a>
        </a>
      </div>
      <div class="col-lg-4">
        <a href="#contact" class="card" style="width: 100%;">
          <img src="assets/OIP (2).jpg" class="card-img-top" alt="Menu">
          <a href="#contact" class="placeholder">horskob</a>
        </a>
      </div>
    </div>
  </div>

  <!-- Main Content -->
  <div class="container mt-5">
    <div class="row">
      <div class="col-lg-8">
        <h2 id="Menu" class="font-weight-normal text-center p-5">Tayangan</h2>
        <div class="row p-3" id="menu-section">
          <div class="col-md-6">
            <h3 class="text-center">Hari ini</h3>
            <div id="drink" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="assets/wa.jpg" class="d-block mx-auto portrait-img" alt="Drink">
                </div>
                <div class="carousel-item">
                  <img src="assets/wa2.jpg" class="d-block mx-auto portrait-img" alt="Drink">
                </div>
                <div class="carousel-item">
                  <img src="assets/download (3).jpg" class="d-block mx-auto portrait-img" alt="Drink">
                </div>
              </div>
              <a class="carousel-control-prev" href="#drink" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </a>
              <a class="carousel-control-next" href="#drink" role="button" data-slide="next">
                <span class="carousel-control-next-icon"></span>
              </a>
            </div>
          </div>

          <div class="col-md-6">
            <h3 class="text-center">Besok</h3>
            <div id="food" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="assets/images.jpg" class="d-block mx-auto portrait-img" alt="Food">
                </div>
                <div class="carousel-item">
                  <img src="assets/download.jpg" class="d-block mx-auto portrait-img" alt="Food">
                </div>
                <div class="carousel-item">
                  <img src="assets/download4.jpg" class="d-block mx-auto portrait-img" alt="Food">
                </div>
              </div>
              <a class="carousel-control-prev" href="#food" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </a>
              <a class="carousel-control-next" href="#food" role="button" data-slide="next">
                <span class="carousel-control-next-icon"></span>
              </a>
            </div>
          </div>
        </div>

        <!-- Profile -->
        <h2 id="profile" class="font-weight-normal text-center p-5">Profil <b>Kami</b></h2>
        <div class="row p-3">
          <p class="text-center">
            <h4>HORSKOB </h4>adalah destinasi utama bagi pecinta film horor sejati.
             Kami menyajikan tayangan-tayangan horor terbaik, mulai dari klasik 
             yang melegenda hingga rilis terbaru yang penuh ketegangan. Dengan s
             uasana yang dibuat khusus untuk menambah sensasi menegangkan, kami
              menghadirkan pengalaman menonton yang tak terlupakan. Nikmati 
              , kejutan, dan adrenalin dalam setiap tayangan hanya di BioskopHoror.
          </p>
           <iframe class="mt-4" width="100%" height="400"
      src="assets/video.mp4"
      title="YouTube video player" frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; 
      gyroscope; picture-in-picture; web-share" allowfullscreen>
    </iframe>
        </div>
      </div>

      <!-- Sidebar Ulasan -->
      <div class="col-lg-4 bg-light p-4" id="review">
        <h2 class="text-center mb-3">Ulasan <b>Penonton</b></h2>
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">anis</h5>
            <p class="card-text">banyak varian film yang bisa dilihat. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Saepe eum quibusdam neque, dolorem quasi consequuntur quia fugit alias voluptates recusandae itaque adipisci tempore maxime distinctio, perspiciatis quas porro quaerat temporibus!</p>
          </div>
        </div>
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">owo</h5>
            <p class="card-text">tempat yang strategis, mudah ditemukan. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Esse dignissimos, quod pariatur consectetur dolorem tempore magnam blanditiis nisi laudantium? Officiis vel consequuntur perspiciatis enim fugit tempora excepturi. Labore, libero animi.</p>
          </div>
        </div>
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">khanjar</h5>
            <p class="card-text">Harga tiket murah, film berkualitas.Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa hic, incidunt laborum pariatur ad vel accusamus iure porro eius quidem distinctio, maiores explicabo? Incidunt eveniet aliquid, ea assumenda facere possimus.top!</p>
          </div>
        </div>
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">owi</h5>
            <p class="card-text">film horor yang sangat masterpiece. Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus officia odio modi id excepturi repellat libero. Quibusdam rem necessitatibus excepturi sunt quaerat tempore deleniti corrupti voluptatem nemo! Nisi, nemo cum.teman-teman.</p>
          </div>
        </div>
      </div>

    </div>
  </div>

  <div id="contact" class="p-100 mt-5">
  <h2 class="text-center font-weight-normal">
    Kontak <b>Kami</b>
  </h2>

  <div class="row mt-4">
    <div class="col-lg-12">

      <!-- Bagian Info Kontak -->

        <div class="zse">
          <div class="mb-3 border-bottom pb-3">
        <h5 class="font-weight-normal">.</h5>
  👻 Selamat datang di <strong>HORSKOB</strong> — tempatnya para pecinta ketegangan dan kengerian!  
  Siapkan nyali, karena setiap tayangan di sini bukan untuk yang berhati lemah... 😱  
  <br>
  Nikmati film-film horor terbaik, hanya di sini!
</div>


      </div>

      <!-- Bagian Sosial Media -->
      <div class="mb-4 border-bottom pb-3">
        <div class="row mb-3">
          <div class="col-sm">
            <div class="row align-items-center">
              <div class="col-3">
                <img src="assets/instagram1.png" width="30" height="30" alt="Instagram">
              </div>
              <div class="col-9">
                <p>horskob</p>
              </div>
            </div>
          </div>

          <div class="col-sm">
            <div class="row align-items-center">
              <div class="col-3">
                <img src="assets/instagram1.png" width="30" height="30" alt="Instagram">
              </div>
              <div class="col-9">
                <p>horskob</p>
              </div>
            </div>
          </div>

          <div class="col-sm">
            <div class="row align-items-center">
              <div class="col-3">
                <img src="assets/instagram1.png" width="30" height="30" alt="Instagram">
              </div>
              <div class="col-9">
                <p>horskob</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Bagian Berlangganan -->
      <div class="mb-3">
        <h3 class="font-weight-normal">Berlangganan Sekarang</h3>
        <button class="btn btn-danger mb-3">Berlangganan</button>
      </div>

      <!-- Bagian Peta (Google Maps) -->
<div class="col-lg-7">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1322372.50608167463!2d112.72780530826542!3d-7.308146470708481!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1i0!2sxd0f7b9e97d072f.excecada1efefcab182!5zUPT Pelatihan Dan Pengembangan Pendidikan Kejuruan / UPT PPK!5e1!3m2!1sid!2sid!4v17177287799955!5m2!1sid!2sid"
        width="100%"
        height="450"
        style="border:0;"
        allowfullscreen=""
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade">
      </iframe>

    </div>
  </div>
</div>

  <!-- Footer -->
  <footer class="bg-dark text-light pt-5 pb-4 mt-5 w-100">
    <div class="container-fluid px-5 text-md-left">
      <div class="row">
        <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
          <h5 class="text-uppercase mb-4 font-weight-bold text-warning">HORSKOB</h5>
          <p>bioskop horor yang setiap harinya membuat penonton ketakutan.</p>
        </div>
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
          <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Navigasi</h5>
          <p><a href="#banner" class="text-light text-decoration-none">Home</a></p>
          <p><a href="#Menu" class="text-light text-decoration-none">Menu</a></p>
          <p><a href="#profile" class="text-light text-decoration-none">Profile</a></p>
          <p><a href="#contact" class="text-light text-decoration-none">Kontak</a></p>
        </div>
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
          <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Kontak</h5>
          <p><i class="fas fa-home me-2"></i>Jl. amba manis. 45, Jakarta</p>
          <p><i class="fas fa-envelope me-2"></i>info@horskob.com</p>
          <p><i class="fas fa-phone me-2"></i>+62 812 3456 7890</p>
          <p><i class="fas fa-print me-2"></i>+62 21 7654 321</p>
        </div>
        <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
          <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Ikuti Kami</h5>
          <a href="#" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-twitter"></i></a>
          <a href="#" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-instagram"></i></a>
          <a href="#" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
      <hr class="mb-4">
      <div class="row align-items-center">
        <div class="col-md-7 col-lg-8"><p>© 2025 <strong>HORSKOB</strong>. All Rights Reserved.</p></div>
        <div class="col-md-5 col-lg-4"><p class="text-end">Dibuat dengan ketakutan</p></div>
      </div>
    </div>
  </footer>

 
  <!-- Scripts -->
  <script src="scripts/jquery-3.7.1.min.js"></script>
  <script src="scripts/bootstrap.bundle.min.js"></script>
</body>
</html>
